# GameZone

Sitio de videojuegos para GitHub Pages: catálogo con 55 juegos, 55 guías, 16 universos, filtros, progreso guardado en el navegador, spoilers desplegables y música de fondo.

La web utiliza HTML, CSS, JavaScript y JSON. No requiere Flask ni una computadora encendida. Las noticias de Vandal se renuevan en cada publicación; cada artículo enlaza a su fuente y muestra un extracto breve. El botón de música incluye pausa y volumen.

## Publicación

En **Settings → Pages → Build and deployment**, elegir **GitHub Actions**. El flujo `Publicar GameZone` publica los cambios de `main` y permite una ejecución manual desde **Actions**.

Los archivos `gamezone-parte-*.bin` son partes de un ZIP que contiene el sitio. GitHub Actions los reúne y extrae al preparar la página pública sin modificar el repositorio. La copia local `GameZone-GitHub-Pages` contiene todos los archivos sin comprimir para editarlos. El flujo también admite los archivos normales en el repositorio cuando no hay partes.

## Contenido

- Páginas `.html`, estilos en `css/` y scripts en `js/`.
- Catálogo en `data/juegos.json` y guías en `guias/`.
- `scripts/actualizar_noticias.py` lee el RSS; si falla, conserva la última copia.
- Los enlaces relativos funcionan en la raíz y bajo el nombre del repositorio.

Las ilustraciones, juegos y pistas conservan sus atribuciones. No se concede una licencia adicional sobre material de terceros.


Esta versión pública conserva la navegación y las guías; los audios locales se omitieron para mantener el paquete ligero para GitHub Pages.
