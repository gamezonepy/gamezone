(() => {
  'use strict';
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)');
  const finePointer = window.matchMedia('(hover: hover) and (pointer: fine)');
  const selector = '.gz-game-card,.gz-news-card,.gz-news-feature,.gz-console-card,.gz-feature-game,.gz-world-card,.gz-spotlight-card,.gz-topic,.gz-discover-card,.gz-home-banner';
  const observed = new WeakSet();
  const animated = new Set();
  const reveal = 'IntersectionObserver' in window ? new IntersectionObserver(entries => {
    for (const entry of entries) {
      if (!entry.isIntersecting) continue;
      entry.target.classList.add('gz-in-view');
      reveal.unobserve(entry.target);
      animated.delete(entry.target);
    }
  }, { threshold: 0.08, rootMargin: '0px 0px 30px 0px' }) : null;

  function enhance(root) {
    const elements = root.matches?.(selector) ? [root, ...root.querySelectorAll(selector)] : [...root.querySelectorAll(selector)];
    elements.forEach((element, index) => {
      if (observed.has(element)) return;
      observed.add(element);
      element.classList.add('gz-motion-card');
      if (!reduced.matches && reveal) {
        element.style.setProperty('--gz-delay', `${Math.min(index % 4, 3) * 65}ms`);
        element.classList.add('gz-reveal');
        animated.add(element);
        reveal.observe(element);
      }
      let frame = 0;
      let position = null;
      element.addEventListener('pointermove', event => {
        if (reduced.matches || !finePointer.matches || event.pointerType === 'touch') return;
        position = [event.clientX, event.clientY];
        if (frame) return;
        frame = requestAnimationFrame(() => {
          frame = 0;
          if (!position || !element.isConnected) return;
          const box = element.getBoundingClientRect();
          element.style.setProperty('--gz-pointer-x', `${position[0] - box.left}px`);
          element.style.setProperty('--gz-pointer-y', `${position[1] - box.top}px`);
        });
      }, { passive: true });
      element.addEventListener('pointerleave', () => {
        position = null;
        if (frame) cancelAnimationFrame(frame);
        frame = 0;
      }, { passive: true });
    });
  }

  enhance(document);
  const main = document.querySelector('main');
  if (main && 'MutationObserver' in window) {
    new MutationObserver(records => {
      for (const record of records) {
        for (const node of record.addedNodes) if (node.nodeType === 1) enhance(node);
        for (const node of record.removedNodes) {
          if (node.nodeType !== 1) continue;
          for (const element of animated) {
            if (element === node || node.contains(element)) {
              reveal?.unobserve(element);
              animated.delete(element);
            }
          }
        }
      }
    }).observe(main, { childList: true, subtree: true });
  }
  reduced.addEventListener('change', () => {
    if (!reduced.matches) return;
    for (const element of animated) {
      element.classList.add('gz-in-view');
      reveal?.unobserve(element);
    }
    animated.clear();
  });
})();
