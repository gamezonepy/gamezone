(() => {
  'use strict';
  const catalogNode = document.getElementById('guide-catalog-data');
  let catalog = [];
  try { catalog = JSON.parse(catalogNode?.textContent || '[]'); } catch { catalog = []; }
  const byId = new Map(catalog.map(game => [String(game.id), game]));
  const normalize = value => String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase('es');

  // The index remains navigable without JavaScript; filters only refine it.
  const search = document.getElementById('guide-search');
  const category = document.getElementById('guide-category');
  const cards = [...document.querySelectorAll('.g-guide-grid[data-filterable] > .g-card')];
  let selectedTag = '';
  function filterCards() {
    const terms = normalize(search?.value).split(/\s+/).filter(Boolean);
    let count = 0;
    cards.forEach(card => {
      const text = normalize(card.dataset.search);
      const match = terms.every(term => text.includes(term)) && (!category?.value || card.dataset.category === category.value) && (!selectedTag || (card.dataset.tags || '').split('|').includes(selectedTag));
      card.hidden = !match;
      if (match) count++;
    });
    const result = document.getElementById('guide-result');
    if (result) result.textContent = `${count} de ${cards.length} guías`;
    const empty = document.getElementById('guide-empty');
    if (empty) empty.hidden = count !== 0;
  }
  search?.addEventListener('input', filterCards);
  category?.addEventListener('change', filterCards);
  document.querySelectorAll('[data-guide-tag]').forEach(button => button.addEventListener('click', () => {
    selectedTag = button.dataset.guideTag || '';
    document.querySelectorAll('[data-guide-tag]').forEach(other => other.setAttribute('aria-pressed', String(other === button)));
    filterCards();
  }));
  function clearFilters() {
    if (search) search.value = '';
    if (category) category.value = '';
    selectedTag = '';
    document.querySelectorAll('[data-guide-tag]').forEach(button => button.setAttribute('aria-pressed', String(!button.dataset.guideTag)));
    filterCards();
    search?.focus();
  }
  document.querySelectorAll('[data-clear-guides]').forEach(button => button.addEventListener('click', clearFilters));
  if (search) {
    search.value = new URLSearchParams(location.search).get('q') || '';
    filterCards();
  }

  const checkboxes = [...document.querySelectorAll('input[data-objective]')];
  const currentId = document.body.dataset.guideId;
  const storageKey = `gamezone:guide:${currentId}:v2`;
  let persistence = true;
  let marked = new Set();
  if (currentId) {
    try {
      const saved = JSON.parse(localStorage.getItem(storageKey) || '[]');
      if (Array.isArray(saved)) marked = new Set(saved.filter(value => typeof value === 'string'));
    } catch { persistence = false; }
    checkboxes.forEach(box => { box.checked = marked.has(box.dataset.objective); });
  }
  function updateProgress(save) {
    const checked = checkboxes.filter(box => box.checked);
    const progress = document.getElementById('guide-progress');
    const label = document.getElementById('guide-progress-label');
    if (progress) { progress.max = Math.max(checkboxes.length, 1); progress.value = checked.length; }
    if (label) label.textContent = `${checked.length} / ${checkboxes.length}`;
    if (save) {
      try { localStorage.setItem(storageKey, JSON.stringify(checked.map(box => box.dataset.objective))); }
      catch { persistence = false; }
    }
    const note = document.getElementById('guide-progress-note');
    if (note) note.textContent = persistence ? 'Tu progreso se guarda en este navegador. No abre los spoilers.' : 'El navegador no permite guardar. El progreso se conserva mientras sigas en esta página.';
  }
  checkboxes.forEach(box => box.addEventListener('change', () => updateProgress(true)));
  document.getElementById('guide-reset-progress')?.addEventListener('click', () => {
    checkboxes.forEach(box => { box.checked = false; });
    updateProgress(true);
  });
  if (currentId) updateProgress(false);
  document.getElementById('guide-close-chapters')?.addEventListener('click', () => {
    document.querySelectorAll('.g-chapter').forEach(chapter => { chapter.open = false; });
  });
  document.querySelectorAll('.g-chapter-nav a').forEach(link => link.addEventListener('click', () => {
    const chapter = document.getElementById(link.hash.slice(1));
    // A chapter-index click is an explicit request to open that chapter.
    if (chapter) chapter.open = true;
  }));
  if ('IntersectionObserver' in window && currentId) {
    const observer = new IntersectionObserver(entries => {
      for (const entry of entries) if (entry.isIntersecting) {
        document.querySelectorAll('.g-chapter-nav a').forEach(link => link.setAttribute('aria-current', String(link.hash === `#${entry.target.id}`)));
      }
    }, { rootMargin: '-15% 0px -65% 0px' });
    document.querySelectorAll('.g-chapter').forEach(chapter => observer.observe(chapter));
  }

  const enableButtons = [...document.querySelectorAll('[data-enable-music]')];
  if (!enableButtons.length) return;
  const audioKey = 'gamezone:audio:v1';
  let preferences = {};
  try { preferences = JSON.parse(sessionStorage.getItem(audioKey) || '{}') || {}; } catch { /* Storage is optional. */ }
  let enabled = preferences.enabled === true;
  let volume = typeof preferences.volume === 'number' && Number.isFinite(preferences.volume) ? Math.min(1, Math.max(0, preferences.volume)) : 0.18;
  let userPaused = preferences.paused === true;
  let generation = 0, fadeTimer = null, hoverTimer = null;
  let hoverCard = null, focusCard = null, pendingCard = null;
  let state = 'paused', notice = '', selected = null;

  // One locally cached recording is preloaded; no external player or video.
  const audio = new Audio();
  audio.id = 'gamezone-background-audio';
  audio.hidden = true;
  audio.setAttribute('aria-hidden', 'true');
  audio.loop = true;
  audio.autoplay = false;
  audio.preload = 'auto';
  audio.volume = volume;
  document.body.appendChild(audio);
  const hasAudio = game => Boolean(game && typeof game.audio?.src === 'string' && /^\/css\/guias-audio\/\d+(?:-[a-f0-9]{12})?\.mp3$/i.test(game.audio.src));
  const savedGame = byId.get(String(preferences.currentId || ''));
  const pageGame = byId.get(String(currentId || ''));
  selected = hasAudio(pageGame) ? pageGame : hasAudio(savedGame) ? savedGame : byId.get('2');
  if (!hasAudio(selected)) selected = catalog.find(hasAudio) || null;

  function element(tag, className, text) {
    const node = document.createElement(tag);
    node.className = className;
    if (text) node.textContent = text;
    return node;
  }
  const bar = element('aside', 'g-audio-bar');
  bar.id = 'g-audio-bar';
  bar.setAttribute('aria-label', 'Música de fondo');
  const copy = element('div', 'g-audio-copy');
  const title = element('p', 'g-audio-title');
  const artist = element('p', 'g-audio-artist');
  const status = element('p', 'g-audio-status');
  status.setAttribute('role', 'status');
  status.setAttribute('aria-live', 'polite');
  copy.append(title, artist, status);
  const controls = element('div', 'g-audio-controls');
  const pauseButton = element('button', 'g-audio-toggle', 'Reproducir');
  pauseButton.type = 'button';
  const volumeLabel = element('label', 'g-audio-volume-wrap', 'Volumen ');
  const volumeInput = document.createElement('input');
  volumeInput.className = 'g-audio-volume';
  volumeInput.type = 'range';
  volumeInput.min = '0'; volumeInput.max = '100'; volumeInput.step = '1';
  volumeInput.value = String(Math.round(volume * 100));
  volumeInput.setAttribute('aria-label', 'Volumen de la música de fondo');
  volumeLabel.appendChild(volumeInput);
  const source = element('a', 'g-audio-source', 'Fuente ↗');
  source.target = '_blank'; source.rel = 'noopener noreferrer';
  const closeButton = element('button', 'g-audio-close', '×');
  closeButton.type = 'button';
  closeButton.setAttribute('aria-label', 'Desactivar la música de fondo');
  controls.append(pauseButton, volumeLabel, source, closeButton);
  bar.append(copy, controls);
  document.body.appendChild(bar);

  function saveAudio() {
    try {
      sessionStorage.setItem(audioKey, JSON.stringify({ enabled, volume, currentId: selected ? String(selected.id) : null, paused: userPaused }));
    } catch { /* Playback works when storage is unavailable. */ }
  }
  function renderAudio() {
    bar.hidden = !enabled;
    bar.dataset.state = state;
    document.body.classList.toggle('g-audio-enabled', enabled);
    enableButtons.forEach(button => {
      button.setAttribute('aria-pressed', String(enabled));
      button.textContent = enabled ? '♫ Música activada' : '♫ Activar música';
    });
    title.textContent = selected ? `${selected.nombre} · ${selected.audio.titulo || 'Música de fondo'}` : 'Música de fondo';
    artist.textContent = selected?.audio.artista || '';
    let sourceURL = '';
    try {
      const url = new URL(selected?.audio.fuente || '', location.origin);
      if (/^https?:$/.test(url.protocol) && selected?.audio.fuente) sourceURL = url.href;
    } catch { /* A missing source never blocks playback. */ }
    source.hidden = !sourceURL;
    if (sourceURL) source.href = sourceURL;
    else source.removeAttribute('href');
    source.setAttribute('aria-label', selected ? `Fuente de ${selected.audio.titulo || 'la música'} de ${selected.nombre}` : 'Fuente de la música');
    pauseButton.disabled = !selected;
    const running = !userPaused && (state === 'playing' || state === 'loading');
    pauseButton.textContent = running ? 'Pausar' : 'Reproducir';
    pauseButton.setAttribute('aria-label', running ? 'Pausar la música de fondo' : 'Reproducir la música de fondo');
    pauseButton.setAttribute('aria-pressed', String(running));
    const messages = {
      playing: 'Sonando de fondo. Puedes seguir leyendo.',
      paused: 'Música en pausa.',
      loading: 'Preparando la música…',
      blocked: 'Pulsa Reproducir para iniciar la música.',
      unavailable: selected ? 'No se pudo reproducir esta pista. Pulsa Reproducir para reintentar.' : 'No hay audio verificado disponible.'
    };
    status.textContent = `${messages[state] || messages.paused}${notice ? ` ${notice}` : ''}`;
  }
  function cancelTransition() {
    generation++;
    clearTimeout(fadeTimer);
    fadeTimer = null;
    audio.volume = volume;
    return generation;
  }
  function fadeTo(target, duration, token, done) {
    const start = audio.volume;
    const started = Date.now();
    function step() {
      if (token !== generation) return;
      const ratio = Math.min(1, (Date.now() - started) / duration);
      const end = target === 0 ? 0 : volume;
      audio.volume = Math.min(1, Math.max(0, start + (end - start) * ratio));
      if (ratio < 1) fadeTimer = setTimeout(step, 20);
      else { fadeTimer = null; if (done) done(); }
    }
    step();
  }
  function playCurrent(token, fade = false) {
    if (!enabled || userPaused || !selected || token !== generation) return;
    if (audio.error) audio.load();
    state = 'loading';
    audio.volume = fade ? 0 : volume;
    renderAudio();
    let attempt;
    // Direct clicks call play synchronously; restored sessions may need a new click.
    try { attempt = audio.play(); } catch (error) { attempt = Promise.reject(error); }
    Promise.resolve(attempt).then(() => {
      if (token !== generation) {
        if (!enabled || userPaused) audio.pause();
        return;
      }
      if (!enabled || userPaused) { audio.pause(); return; }
      state = 'playing';
      renderAudio();
      if (fade) fadeTo(volume || 0.000001, 160, token);
    }).catch(error => {
      if (token !== generation || !enabled || userPaused) return;
      clearTimeout(fadeTimer);
      fadeTimer = null;
      audio.volume = volume;
      state = error?.name === 'NotAllowedError' ? 'blocked' : 'unavailable';
      renderAudio();
    });
  }
  function loadTrack(game) {
    audio.pause();
    selected = game;
    audio.src = game.audio.src;
    audio.load();
    saveAudio();
  }
  function noAudio(game, explicit) {
    notice = `${game.nombre} no tiene audio oficial disponible aquí. ${selected ? `Se conserva el fondo de ${selected.nombre}.` : 'Puedes elegir otra guía en el catálogo.'}`;
    const note = document.getElementById('guide-music-note');
    if (note) note.textContent = 'Puedes mantener la música de fondo que hayas elegido en el catálogo.';
    const token = cancelTransition();
    if (explicit) userPaused = false;
    if (!selected) state = 'unavailable';
    else if (enabled && !userPaused && (audio.paused || state === 'loading') && (explicit || state !== 'blocked')) playCurrent(token);
    else if (!audio.paused && !userPaused) state = 'playing';
    else if (userPaused) state = 'paused';
    saveAudio();
    renderAudio();
  }
  function requestGame(game, explicit = false) {
    if (!enabled || !game) return;
    if (!hasAudio(game)) { noAudio(game, explicit); return; }
    notice = '';
    const note = document.getElementById('guide-music-note');
    if (note) note.textContent = '';
    if (explicit) userPaused = false;
    const token = cancelTransition();
    if (selected && String(selected.id) === String(game.id)) {
      if (!userPaused && (audio.paused || state === 'loading' || state === 'blocked' || state === 'unavailable')) playCurrent(token);
      else { state = userPaused ? 'paused' : 'playing'; renderAudio(); }
      saveAudio();
      return;
    }
    function change() {
      if (token !== generation || !enabled) return;
      loadTrack(game);
      if (userPaused) { state = 'paused'; renderAudio(); }
      else playCurrent(token, true);
    }
    if (!audio.paused && !userPaused) {
      state = 'loading'; renderAudio();
      fadeTo(0, 130, token, change);
    } else change();
  }
  function setEnabled(value) {
    enabled = value;
    clearTimeout(hoverTimer);
    pendingCard = null;
    const token = cancelTransition();
    if (!enabled) { audio.pause(); state = 'paused'; }
    else {
      userPaused = false;
      const candidate = hoverCard || focusCard;
      const game = candidate ? byId.get(candidate.dataset.gameId) : pageGame;
      if (game) requestGame(game, true);
      else if (selected) playCurrent(token);
      else state = 'unavailable';
    }
    saveAudio();
    renderAudio();
  }
  enableButtons.forEach(button => button.addEventListener('click', () => setEnabled(!enabled)));
  closeButton.addEventListener('click', () => setEnabled(false));
  pauseButton.addEventListener('click', () => {
    if (!enabled || !selected) return;
    clearTimeout(hoverTimer);
    pendingCard = null;
    const wasRunning = !userPaused && (state === 'playing' || state === 'loading');
    const token = cancelTransition();
    userPaused = wasRunning;
    if (userPaused) { audio.pause(); state = 'paused'; renderAudio(); }
    else playCurrent(token);
    saveAudio();
  });
  volumeInput.addEventListener('input', () => {
    const value = Number(volumeInput.value);
    if (!Number.isFinite(value)) return;
    volume = Math.min(1, Math.max(0, value / 100));
    if (fadeTimer === null) audio.volume = volume;
    volumeInput.setAttribute('aria-valuetext', `${Math.round(volume * 100)} por ciento`);
    saveAudio();
  });
  function scheduleCard() {
    clearTimeout(hoverTimer);
    pendingCard = hoverCard || focusCard;
    if (!enabled || !pendingCard) return;
    const candidate = pendingCard;
    hoverTimer = setTimeout(() => {
      hoverTimer = null;
      if (enabled && pendingCard === candidate) requestGame(byId.get(candidate.dataset.gameId));
    }, 250);
  }
  document.addEventListener('pointerover', event => {
    if (event.pointerType === 'touch') return;
    const card = event.target.closest('[data-game-id]');
    if (card && !card.contains(event.relatedTarget)) { hoverCard = card; scheduleCard(); }
  });
  document.addEventListener('pointerout', event => {
    const card = event.target.closest('[data-game-id]');
    if (card && !card.contains(event.relatedTarget) && hoverCard === card) { hoverCard = null; scheduleCard(); }
  });
  document.addEventListener('focusin', event => {
    const card = event.target.closest('[data-game-id]');
    if (card && !card.contains(event.relatedTarget)) { focusCard = card; scheduleCard(); }
  });
  document.addEventListener('focusout', event => {
    const card = event.target.closest('[data-game-id]');
    if (card && !card.contains(event.relatedTarget) && focusCard === card) { focusCard = null; scheduleCard(); }
  });
  document.addEventListener('click', event => {
    const button = event.target.closest('[data-play-game]');
    if (!button) return;
    const game = byId.get(button.dataset.playGame);
    if (!game) return;
    clearTimeout(hoverTimer);
    pendingCard = null;
    if (!enabled) { enabled = true; userPaused = false; }
    requestGame(game, true);
    saveAudio();
    renderAudio();
  });
  audio.addEventListener('error', () => {
    if (!enabled || !selected || !audio.error) return;
    cancelTransition();
    audio.pause();
    state = 'unavailable';
    renderAudio();
  });
  window.addEventListener('pagehide', () => {
    saveAudio();
    clearTimeout(hoverTimer);
    cancelTransition();
    audio.pause();
  });
  window.addEventListener('pageshow', event => {
    if (event.persisted && enabled && !userPaused && selected) playCurrent(cancelTransition());
  });
  if (selected) { audio.src = selected.audio.src; audio.load(); }
  if (pageGame && !hasAudio(pageGame)) {
    notice = `${pageGame.nombre} no tiene audio oficial disponible aquí.${selected ? ` El fondo elegido es de ${selected.nombre}.` : ''}`;
    const note = document.getElementById('guide-music-note');
    if (note) note.textContent = 'Puedes mantener la música de fondo que hayas elegido en el catálogo.';
  }
  if (enabled && !userPaused && selected) playCurrent(generation);
  else if (!selected) state = 'unavailable';
  renderAudio();
})();
