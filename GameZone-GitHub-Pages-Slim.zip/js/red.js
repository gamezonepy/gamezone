(() => {
  'use strict';
  const normalize = value => String(value).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase('es').trim();
  const cards = [...document.querySelectorAll('[data-searchable]')];
  const search = document.querySelector('[data-search]');
  const filters = [...document.querySelectorAll('[data-filter]')];
  const count = document.querySelector('[data-count]');
  const empty = document.querySelector('[data-empty]');
  let category = 'Todos';
  function filterCards() {
    const term = normalize(search?.value || '');
    let visible = 0;
    for (const card of cards) {
      card.hidden = !((!term || normalize(card.dataset.searchable).includes(term)) && (category === 'Todos' || card.dataset.category === category));
      if (!card.hidden) visible++;
    }
    if (count) count.textContent = `${visible} de ${cards.length} guías`;
    if (empty) empty.hidden = visible > 0;
  }
  search?.addEventListener('input', filterCards);
  for (const filter of filters) filter.addEventListener('click', () => {
    category = filter.dataset.filter;
    for (const other of filters) other.setAttribute('aria-pressed', String(other === filter));
    filterCards();
  });
  if (cards.length) filterCards();

  const checklist = document.querySelector('[data-guide-progress]');
  if (checklist) {
    const inputs = [...checklist.querySelectorAll('input[type=checkbox]')];
    const key = `gamezone-guide:${checklist.dataset.guideProgress}:v1`;
    const status = document.querySelector('[data-progress-status]');
    const bar = document.querySelector('[data-progress-bar]');
    const reset = document.querySelector('[data-reset-progress]');
    try {
      const saved = JSON.parse(localStorage.getItem(key) || '[]');
      if (Array.isArray(saved)) inputs.forEach((input,index) => {input.checked = saved[index] === true;});
    } catch (_) {}
    function update() {
      const completed = inputs.filter(input => input.checked).length;
      if (status) status.textContent = `${completed} de ${inputs.length} pasos completados`;
      if (bar) {bar.max = inputs.length; bar.value = completed;}
    }
    for (const input of inputs) input.addEventListener('change', () => {
      update();
      try {localStorage.setItem(key, JSON.stringify(inputs.map(item => item.checked)));} catch (_) {}
    });
    reset?.addEventListener('click', () => {
      for (const input of inputs) input.checked = false;
      update();
      try {localStorage.removeItem(key);} catch (_) {}
    });
    update();
  }

  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  const pointer = matchMedia('(hover: hover) and (pointer: fine)');
  const pending = new Set();
  const observer = 'IntersectionObserver' in window ? new IntersectionObserver(entries => {
    for (const entry of entries) if (entry.isIntersecting) {
      entry.target.classList.add('in-view');
      observer.unobserve(entry.target);
      pending.delete(entry.target);
    }
  }, {threshold:.06, rootMargin:'0px 0px 30px 0px'}) : null;
  document.querySelectorAll('.directory-card,.card,.related-card,.banner,.step').forEach((element,index) => {
    element.classList.add('motion-card');
    if (!reduced.matches && observer) {
      element.style.setProperty('--delay', `${(index % 4) * 55}ms`);
      element.classList.add('reveal');
      pending.add(element);
      observer.observe(element);
    }
    let frame = 0;
    let position;
    element.addEventListener('pointermove', event => {
      if (reduced.matches || !pointer.matches || event.pointerType === 'touch') return;
      position = [event.clientX,event.clientY];
      if (frame) return;
      frame = requestAnimationFrame(() => {
        frame = 0;
        if (!position) return;
        const box = element.getBoundingClientRect();
        element.style.setProperty('--pointer-x', `${position[0]-box.left}px`);
        element.style.setProperty('--pointer-y', `${position[1]-box.top}px`);
      });
    }, {passive:true});
    element.addEventListener('pointerleave', () => {position=null;cancelAnimationFrame(frame);frame=0;}, {passive:true});
  });
  reduced.addEventListener('change', () => {
    if (!reduced.matches) return;
    for (const element of pending) {element.classList.add('in-view');observer?.unobserve(element);}
    pending.clear();
  });
})();
