// Mensaje de bienvenida
window.addEventListener("load", () => {
    console.log("Bienvenido a GameZone");
});

// Botón para volver arriba
const botonArriba = document.createElement("button");
botonArriba.innerHTML = "⬆";
botonArriba.id = "btnArriba";
document.body.appendChild(botonArriba);

botonArriba.style.position = "fixed";
botonArriba.style.bottom = "20px";
botonArriba.style.right = "20px";
botonArriba.style.padding = "12px 16px";
botonArriba.style.border = "none";
botonArriba.style.borderRadius = "50%";
botonArriba.style.background = "#00bfff";
botonArriba.style.color = "white";
botonArriba.style.cursor = "pointer";
botonArriba.style.display = "none";
botonArriba.style.fontSize = "18px";

window.addEventListener("scroll", () => {
    if (window.scrollY > 250) {
        botonArriba.style.display = "block";
    } else {
        botonArriba.style.display = "none";
    }
});

botonArriba.addEventListener("click", () => {
    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });
});