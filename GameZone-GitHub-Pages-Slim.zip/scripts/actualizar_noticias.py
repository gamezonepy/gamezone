"""Actualiza el catálogo público de noticias desde el RSS de Vandal."""
import datetime
import gzip
import html
import json
from pathlib import Path
import sys
import urllib.request
import urllib.parse
import xml.etree.ElementTree as ET
from html.parser import HTMLParser

DEST = Path(__file__).resolve().parents[1] / 'data' / 'noticias.json'

class Summary(HTMLParser):
    def __init__(self):
        super().__init__()
        self.text = []
        self.images = []
    def handle_data(self, data):
        self.text.append(data)
    def handle_starttag(self, tag, attrs):
        if tag == 'img':
            attrs = dict(attrs)
            self.images.extend(attrs[key] for key in ['src', 'data-src', 'data-original'] if attrs.get(key))

def safe_url(value, base):
    value = urllib.parse.urljoin(base, html.unescape(value or '').strip())
    return value if urllib.parse.urlsplit(value).scheme in {'http', 'https'} else ''

def update():
    request = urllib.request.Request('https://vandal.elespanol.com/xml.cgi', headers={'User-Agent':'GameZone/1.0'})
    with urllib.request.urlopen(request, timeout=30) as response:
        data = response.read(4_000_001)
    if data.startswith(b'\x1f\x8b'):
        data = gzip.decompress(data)
    if len(data) > 4_000_000:
        raise ValueError('El RSS supera el tamaño esperado')
    root = ET.fromstring(data)
    news = []
    for item in root.findall('.//item')[:60]:
        title = html.unescape(item.findtext('title') or '').strip()
        link = safe_url(item.findtext('link'), 'https://vandal.elespanol.com/')
        if not title or not link:
            continue
        parsed = Summary()
        parsed.feed(item.findtext('description') or '')
        images = []
        for child in item:
            kind = child.tag.rsplit('}', 1)[-1]
            url = child.get('url') or child.get('href')
            mime = child.get('type', '')
            if url and (kind == 'thumbnail' or mime.startswith('image/') or (kind == 'content' and child.get('medium') == 'image')):
                images.append(url)
        images.extend(parsed.images)
        image = next((safe_url(url,link) for url in images if safe_url(url,link)), '')
        # Use short excerpts and link readers to the original article.
        description = ' '.join(' '.join(parsed.text).split())
        if len(description) > 260:
            description = description[:257].rsplit(' ',1)[0] + '…'
        news.append({'titulo':title,'descripcion':description,'enlace':link,'imagen':image,'fuente':'Vandal'})
    if not news:
        raise ValueError('El RSS no contiene noticias válidas')
    DEST.parent.mkdir(parents=True, exist_ok=True)
    DEST.write_text(json.dumps({'actualizado':datetime.datetime.now(datetime.timezone.utc).isoformat(),'noticias':news}, ensure_ascii=False, indent=2), encoding='utf-8')
    print(f'Noticias actualizadas: {len(news)}')

if __name__ == '__main__':
    try:
        update()
    except Exception as error:
        if DEST.exists():
            print(f'No se pudo actualizar el RSS; se conserva la última copia: {error}', file=sys.stderr)
        else:
            raise
